
const userSchema = new mongoose.Schema({
  nom: String,
  prenom: String,
  age: Number,
  cin: String,
  profession: String,
  region: String,
  province: String,
  commune: String,
  adresse: String,
  telephone: String,
  email: String,
  status: { type: String, default: "en attente" },
  validatedByDirectorRegional: {
    type: Boolean,
    default: false,
  }, 
});
module.exports = mongoose.model("User", UserSchema);