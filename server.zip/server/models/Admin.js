const mongoose = require("mongoose");

const AdminSchema = new mongoose.Schema({
  username: {
    type: String,
    required: true,
    unique: true,
  },
  password: {
    type: String,
    required: true,
  },
  role: {
    type: String,
    enum: [
      "admin_general",
      "president_regional",
      "Director_Regional",
      "president_provincial",
      "director_provincial",
    ],
    required: true,
  },
  province: {
    type: String,
    required: function () {
      return (
        this.role === "president_provincial" ||
        this.role === "director_provincial"
      );
    },
  },
});

module.exports = mongoose.model("Admin", AdminSchema);
